//Owen Youngblood
//Lab3
//This code analyzes a given game board of superball and prints out the scoring cell in a valid scoring set
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctype.h>
#include <iostream>
#include <vector>
#include <iomanip>
#include <set>
#include "disjoint.h"
using namespace std;

#define talloc(type, num) (type *) malloc(sizeof(type)*(num))

class Superball {
  public:
    Superball(int argc, char **argv);
    int r;
    int c;
    int mss;
    int empty;
    vector <int> board;
    vector <int> goals;
    vector <int> colors;
    void analyze_superball();
};

void usage(const char *s) 
{
  fprintf(stderr, "usage: sb-read rows cols min-score-size colors\n");
  if (s != NULL) fprintf(stderr, "%s\n", s);
  exit(1);
}

Superball::Superball(int argc, char **argv)
{
  int i, j;
  string s;

  if (argc != 5) usage(NULL);

  if (sscanf(argv[1], "%d", &r) == 0 || r <= 0) usage("Bad rows");
  if (sscanf(argv[2], "%d", &c) == 0 || c <= 0) usage("Bad cols");
  if (sscanf(argv[3], "%d", &mss) == 0 || mss <= 0) usage("Bad min-score-size");

  colors.resize(256, 0);

  for (i = 0; i < strlen(argv[4]); i++) {
    if (!isalpha(argv[4][i])) usage("Colors must be distinct letters");
    if (!islower(argv[4][i])) usage("Colors must be lowercase letters");
    if (colors[argv[4][i]] != 0) usage("Duplicate color");
    colors[argv[4][i]] = 2+i;
    colors[toupper(argv[4][i])] = 2+i;
  }

  board.resize(r*c);
  goals.resize(r*c, 0);

  empty = 0;

  for (i = 0; i < r; i++) {
    if (!(cin >> s)) {
      fprintf(stderr, "Bad board: not enough rows on standard input\n");
      exit(1);
    }
    if (s.size() != c) {
      fprintf(stderr, "Bad board on row %d - wrong number of characters.\n", i);
      exit(1);
    }
    for (j = 0; j < c; j++) {
      if (s[j] != '*' && s[j] != '.' && colors[s[j]] == 0) {
        fprintf(stderr, "Bad board row %d - bad character %c.\n", i, s[j]);
        exit(1);
      }
      board[i*c+j] = s[j];
      if (board[i*c+j] == '.') empty++;
      if (board[i*c+j] == '*') empty++;
      if (isupper(board[i*c+j]) || board[i*c+j] == '*') {
        goals[i*c+j] = 1;
        board[i*c+j] = tolower(board[i*c+j]);
      }
    }
  }
}

void Superball::analyze_superball() 
{
    //as hinted by zach in the Lab-questions discord chat
    DisjointSetByRankWPC *ds = new DisjointSetByRankWPC(r * c);
    for (int i = 0; i < r * c; i++) 
    {
        ds->Find(i);
    }
    //Union adjacent cells of the same color (as hinted by zach in the Lab-questions discord chat)
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            int index = i * c + j;
            // Check right cell
            if (j + 1 < c && board[index] == board[index + 1] && board[index] != '.' && board[index] != '*') 
            {
                int setIdLeft = ds->Find(index);
                int setIdRight = ds->Find(index+1);
                if(setIdLeft != setIdRight)
                {
                  ds->Union(setIdLeft,setIdRight);
                }
            }
            // Check bottom cell
            if (i + 1 < r && board[index] == board[index + c] && board[index] != '.' && board[index] != '*') 
            {
                int setIdLeft = ds->Find(index);
                int setIdRight = ds->Find(index+c);
                if(setIdLeft != setIdRight)
                {
                  ds->Union(setIdLeft,setIdRight);
                }
            }
        }
    }
    vector<int> component_sizes(r * c, 0);
    vector<int> goal_rows(r * c, -1); //Vector for row indices of goal cells
    vector<int> goal_cols(r * c, -1); //Vector for column indices of goal cells
    for (int i = 0; i < r * c; i++) 
    {
        if (board[i] != '.' && board[i] != '*') 
        {
            int root = ds->Find(i);
            component_sizes[root]++;
            if (goals[i] == 1) 
            {
                goal_rows[root] = i / c;
                goal_cols[root] = i % c;
            }
        }
    }
    cout << "Scoring sets:" << endl;
    vector<bool> printed_roots(r * c, false);//to stop from printing the same scoring set twice
    for (int i = 0; i < r * c; i++) 
    {
        int root = ds->Find(i);
        if (component_sizes[root] >= mss && goal_rows[root] != -1 && !printed_roots[root]) 
        {
            char scoringChar = board[root];
            cout << "  Size: " << setw(2) << component_sizes[root] << "  Char: " << scoringChar << "  Scoring Cell: " << goal_rows[root] << "," << goal_cols[root] << endl;
            printed_roots[root] = true;
        }
    }

}

int main(int argc, char **argv)
{
  Superball *s;
  s = new Superball(argc, argv);
  s->analyze_superball();
  delete s;
  return 0;
}

